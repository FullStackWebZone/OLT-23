# css-water-drop  
Demo  

https://nuruddin-bin.github.io/css-water-drop/
