document.addEventListener('DOMContentLoaded', (event) => {
  event.preventDefault();

  const before = document.querySelector('#lyrics').innerText;

  document.querySelector('#lyrics').innerText = before.toLowerCase();
});